#ifndef GUARD_BATTLE_811DA74_H
#define GUARD_BATTLE_811DA74_H

void SetBankFuncToLinkPartnerBufferRunCommand(void);
void LinkPartnerBufferRunCommand(void);
void sub_811E0A0(void);
void LinkPartnerBufferExecCompleted(void);
u32 dp01_getattr_by_ch1_for_player_pokemon(u8 a, u8 *b);
void sub_811EC68(u8);

#endif // GUARD_BATTLE_811DA74_H
