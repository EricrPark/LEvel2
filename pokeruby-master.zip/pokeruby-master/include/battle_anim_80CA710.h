#ifndef GUARD_BATTLE_ANIM_80CA710_H
#define GUARD_BATTLE_ANIM_80CA710_H

void sub_80E4EF8(int, int, int, int, u16, u8, int);
s16 sub_81174E0(s16 a);
s16 sub_81174C4(s16 a, s16 b);

#endif // GUARD_BATTLE_ANIM_80CA710_H
