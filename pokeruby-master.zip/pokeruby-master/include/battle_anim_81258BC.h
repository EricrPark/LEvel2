#ifndef GUARD_BATTLE_ANIM_81258BC_H
#define GUARD_BATTLE_ANIM_81258BC_H

void SetBankFuncToSafariBufferRunCommand(void);
void bx_battle_menu_t6_2(void);

#endif // GUARD_BATTLE_ANIM_81258BC_H
