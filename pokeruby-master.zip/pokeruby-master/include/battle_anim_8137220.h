#ifndef GUARD_BATTLE_ANIM_8137220_H
#define GUARD_BATTLE_ANIM_8137220_H

void SetBankFuncToWallyBufferRunCommand(void);

#endif // GUARD_BATTLE_ANIM_8137220_H
