#ifndef GUARD_BATTLE_PARTY_MENU_H
#define GUARD_BATTLE_PARTY_MENU_H

void HandleBattlePartyMenu(u8);
bool8 SetUpBattlePartyMenu(void);

#endif
