#ifndef GUARD_BATTLE_RECORDS_H
#define GUARD_BATTLE_RECORDS_H

void InitLinkBattleRecords(void);
void UpdateLinkBattleRecords(int id);
void ShowLinkBattleRecords(void);
void ShowBattleTowerRecords(void);

#endif // GUARD_BATTLE_RECORDS_H
