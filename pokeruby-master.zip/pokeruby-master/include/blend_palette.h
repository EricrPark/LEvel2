#ifndef GUARD_BLEND_PALETTE_H
#define GUARD_BLEND_PALETTE_H

void BlendPalette(u16 palOffset, u16 numEntries, u8 coeff, u16 blendColor);

#endif // GUARD_BLEND_PALETTE_H
