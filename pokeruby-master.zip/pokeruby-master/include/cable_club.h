#ifndef GUARD_CABLE_CLUB_H
#define GUARD_CABLE_CLUB_H

#include "task.h"

void sub_808347C(u8 arg0);
void sub_80834E4(void);
void sub_808350C(void);
void sub_80835D8(void);
void sub_8083614(void);
void sub_808363C(void);
u8 sub_8083664(void);
void sub_8083820(void);
void sub_80839A4(void);
void sub_80839D0(void);
void sub_8083A84(TaskFunc followupFunc);
void sub_8083B5C(void);
void sub_8083B80(void);
void sub_8083B90(void);
void sub_8083BDC(void);
bool32 sub_8083BF4(u8 linkPlayerIndex);
void sub_8083C50(u8 taskId);

#endif // GUARD_CABLE_CLUB_H
