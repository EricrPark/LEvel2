#ifndef GUARD_CLEAR_SAVE_DATA_MENU_H
#define GUARD_CLEAR_SAVE_DATA_MENU_H

void CB2_InitClearSaveDataScreen(void);

#endif // GUARD_CLEAR_SAVE_DATA_MENU_H
