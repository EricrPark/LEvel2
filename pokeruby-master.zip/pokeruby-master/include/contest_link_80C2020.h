#ifndef GUARD_CONTEST_LINK_80C2020_H
#define GUARD_CONTEST_LINK_80C2020_H

void sub_80C2358(void);
void sub_80C46EC(void);
void sub_80C4740(void);
void sub_80C48C8(void);
void sub_80C48F4(void);
void sub_80C4940(void);
void sub_80C4980(u8);
u8 sub_80C4B34(u8 *);

#endif // GUARD_CONTEST_LINK_80C2020_H
