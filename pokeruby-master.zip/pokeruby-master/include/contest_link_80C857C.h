#ifndef GUARD_CONTEST_LINK_80C857C_H
#define GUARD_CONTEST_LINK_80C857C_H

void sub_80C8734(u8);
void sub_80C88AC(u8);
void sub_80C89DC(u8);
void sub_80C8E1C(u8);
void sub_80C8EBC(u8);
void sub_80C8F34(u8);

#endif // GUARD_CONTEST_LINK_80C857C_H
