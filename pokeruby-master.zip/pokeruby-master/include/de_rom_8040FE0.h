#ifndef GUARD_DE_ROM_8040FE0
#define GUARD_DE_ROM_8040FE0

u8 *de_sub_8041024(s32 arg0, u32 arg1);

#endif // GUARD_DE_ROM_8040FE0
