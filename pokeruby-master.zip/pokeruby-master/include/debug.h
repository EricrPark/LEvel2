#ifndef GUARD_DEBUG_H
#define GUARD_DEBUG_H

// matsuda_debug_menu
void sub_80AAF30(void);

#endif // GUARD_DEBUG_H
