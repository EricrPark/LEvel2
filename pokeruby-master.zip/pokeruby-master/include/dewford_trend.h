#ifndef GUARD_DEWFORDTREND_H
#define GUARD_DEWFORDTREND_H

void InitDewfordTrend(void);
void sub_80FA4E4(void *, u32, u8);
void UpdateDewfordTrendPerDay(u16);

#endif
