#ifndef GUARD_DIPLOMA_H
#define GUARD_DIPLOMA_H

void CB2_ShowDiploma(void);

#endif // GUARD_DIPLOMA_H
