#ifndef GUARD_FIELD_POISON_H
#define GUARD_FIELD_POISON_H

s32 DoPoisonFieldEffect(void);

#endif // GUARD_FIELD_POISON_H
