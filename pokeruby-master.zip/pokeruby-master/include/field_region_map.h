#ifndef GUARD_FIELD_REGION_MAP_H
#define GUARD_FIELD_REGION_MAP_H

void FieldInitRegionMap(void(void));
void CB2_FieldInitRegionMap(void);
void VBlankCB_FieldRegionMap(void);
void CB2_FieldRegionMap(void);
void sub_813EFDC(void);
void sub_813F0C8(void);

#endif // GUARD_FIELD_REGION_MAP_H
