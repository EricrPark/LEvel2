#ifndef GUARD_FLDEFF_CUT_H
#define GUARD_FLDEFF_CUT_H

void sub_80A25E8(void);
void sub_80A2634(void);
void sub_80A2684(void);
void sub_80A27A8(s16, s16);
void sub_80A28F4(s16, s16);
void objc_8097BBC(struct Sprite *sprite);
void sub_80A2AB8(void);
void sub_80A2B00(void); // unknown args

#endif // GUARD_FLDEFF_CUT_H
