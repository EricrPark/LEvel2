#ifndef GUARD_FLDEFF_DECORATION_H
#define GUARD_FLDEFF_DECORATION_H

void sub_80C68A4(s16 metatileId, s16 x, s16 y);
void sub_80C6A54(s16 x, s16 y);
void DoDecorationSoundEffect(s16 metatileId);
void DoYellowCave4Sparkle(void);

#endif // GUARD_FLDEFF_DECORATION_H
