#ifndef GUARD_FLDEFF_FLASH_H
#define GUARD_FLDEFF_FLASH_H

void sub_810CC80(void);
u8 sub_810CDB8(u8, u8);
u8 fade_type_for_given_maplight_pair(u8, u8);

#endif // GUARD_FLDEFF_FLASH_H
