#ifndef GUARD_FLDEFF_POISON_H
#define GUARD_FLDEFF_POISON_H

void DoFieldPoisonEffect(void);
bool32 FieldPoisonEffectIsRunning(void);

#endif // GUARD_FLDEFF_POISON_H
