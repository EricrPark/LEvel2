#ifndef GUARD_FLDEFF_RECORDMIXING_H
#define GUARD_FLDEFF_RECORDMIXING_H

u8 CreateRecordMixingSprite(void);
void DestroyRecordMixingSprite(void);

#endif // GUARD_FLDEFF_RECORDMIXING_H
