#ifndef GUARD_FLDEFF_SOFTBOILED_H
#define GUARD_FLDEFF_SOFTBOILED_H

bool8 SetUpFieldMove_SoftBoiled(void);
void sub_8133D28(u8 taskid);

#endif // GUARD_FLDEFF_SOFTBOILED_H
