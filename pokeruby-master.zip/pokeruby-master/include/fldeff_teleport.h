#ifndef GUARD_FLDEFF_TELEPORT_H
#define GUARD_FLDEFF_TELEPORT_H

void hm_teleport_run_dp02scr(void);
void sub_814A404(void);

#endif // GUARD_FLDEFF_TELEPORT_H
