#ifndef GUARD_HALL_OF_FAME_H
#define GUARD_HALL_OF_FAME_H

void sub_8141F90(void);
void sub_8143648(u16 paletteTag, u8 arg1);
void sub_81428CC(void);
void sub_8143680(int, u8);

#endif // GUARD_HALL_OF_FAME_H
