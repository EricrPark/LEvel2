#ifndef GUARD_INTRO_H
#define GUARD_INTRO_H

void CB2_InitCopyrightScreenAfterBootup(void);
void CB2_InitCopyrightScreenAfterTitleScreen(void);
void sub_813CE30(u16, u16, u16, u16);

#endif // GUARD_INTRO_H
