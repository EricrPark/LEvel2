#ifndef GUARD_LANDMARK_H
#define GUARD_LANDMARK_H

const u8 *GetLandmarkName(u8 mapSection, u8 id, u8 count);

#endif // GUARD_LANDMARK_H
