#ifndef GUARD_LEARN_MOVE_H
#define GUARD_LEARN_MOVE_H

void sub_8132670(void);

#endif // GUARD_LEARN_MOVE_H
