#ifndef GUARD_MAIL_H
#define GUARD_MAIL_H

#include "main.h"

void HandleReadMail(struct MailStruct *arg0, MainCallback arg1, bool8 arg2);

#endif // GUARD_MAIL_H
