#ifndef GUARD_MAP_NAME_POPUP_H
#define GUARD_MAP_NAME_POPUP_H

void ShowMapNamePopup(void);
void HideMapNamePopup();

#endif // GUARD_MAP_NAME_POPUP_H
