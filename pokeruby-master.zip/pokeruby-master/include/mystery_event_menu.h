#ifndef GUARD_MYSTERY_EVENT_MENU_H
#define GUARD_MYSTERY_EVENT_MENU_H

void CB2_InitMysteryEventMenu(void);

#endif // GUARD_MYSTERY_EVENT_MENU_H
