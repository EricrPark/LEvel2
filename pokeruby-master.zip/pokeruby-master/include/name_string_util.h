#ifndef GUARD_NAMESTRINGUTIL_H
#define GUARD_NAMESTRINGUTIL_H

void PadNameString(u8 *a1, u8 a2);
void SanitizeNameString(u8 *a1);

#endif
