#ifndef GUARD_POKEDEX_AREA_SCREEN_H
#define GUARD_POKEDEX_AREA_SCREEN_H

void ShowPokedexAreaScreen(u16 species, u8 *string);

#endif // GUARD_POKEDEX_AREA_SCREEN_H
