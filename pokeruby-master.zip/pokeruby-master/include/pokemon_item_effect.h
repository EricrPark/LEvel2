#ifndef GUARD_POKEMON_ITEM_EFFECT_H
#define GUARD_POKEMON_ITEM_EFFECT_H

bool8 ExecuteTableBasedItemEffect_(struct Pokemon *mon, u16, u8, u16);

#endif // GUARD_POKEMON_ITEM_EFFECT_H
