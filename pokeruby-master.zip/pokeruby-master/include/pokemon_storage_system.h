#ifndef GUARD_POKEMON_STORAGE_SYSTEM_H
#define GUARD_POKEMON_STORAGE_SYSTEM_H

void ResetPokemonStorageSystem(void);
void BoxMonRestorePP(struct BoxPokemon *);
void party_compaction(void);

#endif // GUARD_POKEMON_STORAGE_SYSTEM_H
