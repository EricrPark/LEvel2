#ifndef GUARD_RESET_RTC_SCREEN_H
#define GUARD_RESET_RTC_SCREEN_H

void CB2_InitResetRtcScreen(void);

#endif // GUARD_RESET_RTC_SCREEN_H
