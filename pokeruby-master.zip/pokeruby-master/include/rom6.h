#ifndef GUARD_ROM6_H
#define GUARD_ROM6_H

extern struct MapPosition gUnknown_0203923C;

bool8 npc_before_player_of_type(u8);
u8 oei_task_add(void);

#endif
