#ifndef GUARD_ROM_8094928_H
#define GUARD_ROM_8094928_H

void sub_8094978(u8, u8);
u8 sub_8094C20(u8);
void sub_8094C98(u8, u8);
u8 pokemon_order_func(u8);
void sub_8094E4C(void);

#endif // GUARD_ROM_8094928_H
