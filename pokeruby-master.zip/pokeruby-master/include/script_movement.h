#ifndef GUARD_SCRIPT_MOVEMENT_H
#define GUARD_SCRIPT_MOVEMENT_H

bool8 ScriptMovement_StartObjectMovementScript(u8, u8, u8, const u8 *);
bool8 ScriptMovement_IsObjectMovementFinished(u8, u8, u8);
void sub_80A2178(void);

#endif // GUARD_SCRIPT_MOVEMENT_H
