#ifndef GUARD_SLOT_MACHINE_H
#define GUARD_SLOT_MACHINE_H

void PlaySlotMachine(u8, void *);
void sub_8104DA4(void);
u8 sub_8105BB4(u8, u8, s16);

#endif // GUARD_SLOT_MACHINE_H
