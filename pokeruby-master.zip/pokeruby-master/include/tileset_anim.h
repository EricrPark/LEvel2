#ifndef GUARD_TITLE_SCREEN_H
#define GUARD_TITLE_SCREEN_H

void sub_8072E74(void);
void cur_mapheader_run_tileset_funcs_after_some_cpuset(void);
void sub_8072ED0(void);
void sub_8072EDC(void);
void TilesetCB_General(void);
void TilesetCB_Building(void);
void TilesetCB_Petalburg(void);
void TilesetCB_Rustboro(void);
void TilesetCB_Dewford(void);
void TilesetCB_Slateport(void);
void TilesetCB_Mauville(void);
void TilesetCB_Lavaridge(void);
void TilesetCB_Fallarbor(void);
void TilesetCB_Fortree(void);
void TilesetCB_Lilycove(void);
void TilesetCB_Mossdeep(void);
void TilesetCB_EverGrande(void);
void TilesetCB_Pacifidlog(void);
void TilesetCB_Sootopolis(void);
void TilesetCB_Underwater(void);
void TilesetCB_SootopolisGym(void);
void TilesetCB_Cave(void);
void TilesetCB_EliteFour(void);
void TilesetCB_MauvilleGym(void);
void TilesetCB_BikeShop(void);

#endif // GUARD_TITLE_SCREEN_H
