#ifndef GUARD_TRADER_H
#define GUARD_TRADER_H

void TraderSetup(void);
void sub_8109A20(void);

#endif // GUARD_TRADER_H
