//
// Created by Scott Norton on 5/31/17.
//

#ifndef POKERUBY_USE_POKEBLOCK_H
#define POKERUBY_USE_POKEBLOCK_H

extern void *gUnknown_02030400;
extern s16 gUnknown_02039312;

void sub_8136130(struct Pokeblock *, MainCallback);

#endif //POKERUBY_USE_POKEBLOCK_H
