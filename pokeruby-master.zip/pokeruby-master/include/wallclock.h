#ifndef GUARD_WALLCLOCK_H
#define GUARD_WALLCLOCK_H

#include "sprite.h"

void CB2_StartWallClock(void);
void CB2_ViewWallClock(void);

#endif // GUARD_WALLCLOCK_H
