
// Includes
#include "global.h"

// Static type declarations

// Static RAM declarations

IWRAM_DATA u32 filler_03000724;
IWRAM_DATA u16 gUnknown_03000728[4];
IWRAM_DATA u16 gUnknown_03000730[6];
IWRAM_DATA u32 filler_0300073c;

// Static ROM declarations

// .rodata

// .text
