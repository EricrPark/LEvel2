//

//

#ifndef POKERUBY_ANIM_FUNC_PTRS_H
#define POKERUBY_ANIM_FUNC_PTRS_H

u8 sub_8060CE0(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8060CF0(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8060D00(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8060D10(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8060F3C(struct MapObject *, struct Sprite *);
u8 sub_8060F5C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8060F7C(struct MapObject *, struct Sprite *);
u8 sub_8060F9C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8060FBC(struct MapObject *, struct Sprite *);
u8 sub_8060FDC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8060FFC(struct MapObject *, struct Sprite *);
u8 sub_806101C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806103C(struct MapObject *, struct Sprite *);
u8 sub_806105C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806107C(struct MapObject *, struct Sprite *);
u8 sub_806109C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80610BC(struct MapObject *, struct Sprite *);
u8 sub_80610DC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80610FC(struct MapObject *, struct Sprite *);
u8 sub_806111C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80613A8(struct MapObject *, struct Sprite *);
u8 sub_80613D4(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061400(struct MapObject *, struct Sprite *);
u8 sub_806142C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061458(struct MapObject *, struct Sprite *);
u8 sub_8061484(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80614B0(struct MapObject *, struct Sprite *);
u8 sub_80614DC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806152C(struct MapObject *, struct Sprite *);
u8 sub_8061510(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806154C(struct MapObject *, struct Sprite *);
u8 sub_8061510(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806156C(struct MapObject *, struct Sprite *);
u8 sub_8061510(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806158C(struct MapObject *, struct Sprite *);
u8 sub_8061510(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_80615AC(struct MapObject *, struct Sprite *);
u8 sub_8061510(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_80615CC(struct MapObject *, struct Sprite *);
u8 sub_80615EC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806160C(struct MapObject *, struct Sprite *);
u8 sub_806162C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806164C(struct MapObject *, struct Sprite *);
u8 sub_806166C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806168C(struct MapObject *, struct Sprite *);
u8 sub_80616AC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061778(struct MapObject *, struct Sprite *);
u8 sub_806173C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80617B0(struct MapObject *, struct Sprite *);
u8 sub_806173C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80617E8(struct MapObject *, struct Sprite *);
u8 sub_806173C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061820(struct MapObject *, struct Sprite *);
u8 sub_806173C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061858(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061890(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80618C8(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061900(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061938(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061970(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80619A8(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80619E0(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061A18(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061A50(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061A88(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061AC0(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061AF8(struct MapObject *, struct Sprite *);
u8 sub_8061B18(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061B38(struct MapObject *, struct Sprite *);
u8 sub_8061B58(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061B78(struct MapObject *, struct Sprite *);
u8 sub_8061B98(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061BB8(struct MapObject *, struct Sprite *);
u8 sub_8061BD8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061BF8(struct MapObject *, struct Sprite *);
u8 sub_8061C18(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061C38(struct MapObject *, struct Sprite *);
u8 sub_8061C58(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061C78(struct MapObject *, struct Sprite *);
u8 sub_8061C98(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061CB8(struct MapObject *, struct Sprite *);
u8 sub_8061CD8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061CF8(struct MapObject *, struct Sprite *);
u8 sub_8061D18(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061D38(struct MapObject *, struct Sprite *);
u8 sub_8061D58(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061D78(struct MapObject *, struct Sprite *);
u8 sub_8061D98(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061DB8(struct MapObject *, struct Sprite *);
u8 sub_8061DD8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 do_run_south_anim(struct MapObject *, struct Sprite *);
u8 sub_8061E18(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 do_run_north_anim(struct MapObject *, struct Sprite *);
u8 sub_8061E58(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 do_run_west_anim(struct MapObject *, struct Sprite *);
u8 sub_8061E98(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 do_run_east_anim(struct MapObject *, struct Sprite *);
u8 sub_8061ED8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061F24(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061F90(struct MapObject *, struct Sprite *);
u8 sub_8061FB0(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8061FD8(struct MapObject *, struct Sprite *);
u8 sub_8061FF8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062020(struct MapObject *, struct Sprite *);
u8 sub_8062040(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062068(struct MapObject *, struct Sprite *);
u8 sub_8062088(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80620B0(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806210C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062170(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062180(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062190(struct MapObject *, struct Sprite *);
u8 sub_80621BC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80621E8(struct MapObject *, struct Sprite *);
u8 sub_8062214(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062240(struct MapObject *, struct Sprite *);
u8 sub_806226C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062298(struct MapObject *, struct Sprite *);
u8 sub_80622C4(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80622F0(struct MapObject *, struct Sprite *);
u8 sub_806231C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062348(struct MapObject *, struct Sprite *);
u8 sub_8062374(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80623A0(struct MapObject *, struct Sprite *);
u8 sub_80623CC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80623F8(struct MapObject *, struct Sprite *);
u8 sub_8062424(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062450(struct MapObject *, struct Sprite *);
u8 sub_806247C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80624A8(struct MapObject *, struct Sprite *);
u8 sub_80624D4(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062500(struct MapObject *, struct Sprite *);
u8 sub_806252C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062558(struct MapObject *, struct Sprite *);
u8 sub_8062584(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80625B0(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80625C8(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80625D8(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_80625E8(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_80625F8(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_8062608(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_8062634(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_8062644(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 do_exclamation_mark_bubble_1(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 do_exclamation_mark_bubble_2(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 do_heart_bubble(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_80626C0(struct MapObject *, struct Sprite *);
u8 sub_8062704(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_8062724(struct MapObject *, struct Sprite *);
u8 sub_8062740(struct MapObject *, struct Sprite *);
u8 sub_8062764(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_80627A0(struct MapObject *, struct Sprite *);
u8 sub_80627BC(struct MapObject *, struct Sprite *);
u8 sub_80627E0(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806281C(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806282C(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806283C(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806286C(struct MapObject *, struct Sprite *);
u8 sub_8063470(struct MapObject *, struct Sprite *);
u8 sub_806289C(struct MapObject *, struct Sprite *);
u8 sub_80628D0(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80628FC(struct MapObject *, struct Sprite *);
u8 sub_8062930(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_806299C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80629AC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80629BC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80629CC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80629DC(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062A00(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062A24(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062A48(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062A6C(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062A90(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062AB4(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062AD8(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062AFC(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062B20(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062B44(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062B68(struct MapObject *, struct Sprite *);
u8 sub_8061F3C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062BD0(struct MapObject *, struct Sprite *);
u8 sub_8062BFC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062C28(struct MapObject *, struct Sprite *);
u8 sub_8062C54(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062C80(struct MapObject *, struct Sprite *);
u8 sub_8062CAC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062CD8(struct MapObject *, struct Sprite *);
u8 sub_8062D04(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062D30(struct MapObject *, struct Sprite *);
u8 sub_8062D5C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062D88(struct MapObject *, struct Sprite *);
u8 sub_8062DB4(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062DE0(struct MapObject *, struct Sprite *);
u8 sub_8062E0C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062E38(struct MapObject *, struct Sprite *);
u8 sub_8062E64(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062E90(struct MapObject *, struct Sprite *);
u8 sub_8062EBC(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062EE8(struct MapObject *, struct Sprite *);
u8 sub_8062F14(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062F40(struct MapObject *, struct Sprite *);
u8 sub_8062F6C(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062F98(struct MapObject *, struct Sprite *);
u8 sub_8062FC4(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8062FF0(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063028(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063060(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063098(struct MapObject *, struct Sprite *);
u8 sub_8061714(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063108(struct MapObject *, struct Sprite *);
u8 sub_8063128(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063148(struct MapObject *, struct Sprite *);
u8 sub_8063168(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063188(struct MapObject *, struct Sprite *);
u8 sub_80631A8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80631C8(struct MapObject *, struct Sprite *);
u8 sub_80631E8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063238(struct MapObject *, struct Sprite *);
u8 sub_8063258(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063278(struct MapObject *, struct Sprite *);
u8 sub_8063298(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80632B8(struct MapObject *, struct Sprite *);
u8 sub_80632D8(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80632F8(struct MapObject *, struct Sprite *);
u8 sub_8063318(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063370(struct MapObject *, struct Sprite *);
u8 sub_8063390(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80633B0(struct MapObject *, struct Sprite *);
u8 sub_80633D0(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_80633F0(struct MapObject *, struct Sprite *);
u8 sub_8063410(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);
u8 sub_8063430(struct MapObject *, struct Sprite *);
u8 sub_8063450(struct MapObject *, struct Sprite *);
u8 sub_8063474(struct MapObject *, struct Sprite *);

u8 (*const Unknown_83759A0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_83759A8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_83759B0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_83759B8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_83759D4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_83759E0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_83759EC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_83759F8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A04[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A10[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A1C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A28[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A40[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A4C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A58[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A64[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A70[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A7C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A88[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375A94[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375AA0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375AAC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375AB8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375AC4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375AD0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375ADC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375AE8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375AF4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B00[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B0C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B18[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B24[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B30[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B3C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B48[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B54[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B60[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B6C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B78[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B84[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B90[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375B9C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BA8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BB4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BC0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BCC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BD8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BE4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BF0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375BFC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C08[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C14[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C20[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C2C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C38[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C44[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C50[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C5C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C68[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C74[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C80[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C8C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375C98[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CA0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CA8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CB0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CB8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CC4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CD0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CDC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CE8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375CF4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D00[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D0C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D18[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D24[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D30[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D3C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D48[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D50[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D5C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D64[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D6C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D74[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D7C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D84[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D8C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D94[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375D9C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DA4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DB0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DC0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DD0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DD8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DE0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DE8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DF0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375DFC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E08[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E10[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E18[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E20[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E28[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E34[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E40[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E4C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E58[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E64[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E70[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375E7C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375EB8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375EC4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375ED0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375EDC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375EE8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375EF4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F00[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F0C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F18[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F24[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F30[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F3C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F48[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F54[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F60[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F6C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F78[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F84[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F90[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375F9C[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FA8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FB4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FC0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FCC[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FD8[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FE4[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FF0[])(struct MapObject *, struct Sprite *);
u8 (*const Unknown_8375FFC[])(struct MapObject *, struct Sprite *);

u8 (*const *const gUnknown_08375778[])(struct MapObject *, struct Sprite *) = {
    Unknown_83759A0,
    Unknown_83759A8,
    Unknown_83759B0,
    Unknown_83759B8,
    Unknown_83759D4,
    Unknown_83759E0,
    Unknown_83759EC,
    Unknown_83759F8,
    Unknown_8375A04,
    Unknown_8375A10,
    Unknown_8375A1C,
    Unknown_8375A28,
    Unknown_8375A40,
    Unknown_8375A4C,
    Unknown_8375A58,
    Unknown_8375A64,
    Unknown_8375A70,
    Unknown_8375A7C,
    Unknown_8375A88,
    Unknown_8375A94,
    Unknown_8375AA0,
    Unknown_8375AAC,
    Unknown_8375AB8,
    Unknown_8375AC4,
    Unknown_8375AD0,
    Unknown_8375ADC,
    Unknown_8375AE8,
    Unknown_8375AF4,
    Unknown_8375B00,
    Unknown_8375B0C,
    Unknown_8375B18,
    Unknown_8375B24,
    Unknown_8375B30,
    Unknown_8375B3C,
    Unknown_8375B48,
    Unknown_8375B54,
    Unknown_8375B60,
    Unknown_8375B6C,
    Unknown_8375B78,
    Unknown_8375B84,
    Unknown_8375B90,
    Unknown_8375B9C,
    Unknown_8375BA8,
    Unknown_8375BB4,
    Unknown_8375BC0,
    Unknown_8375BCC,
    Unknown_8375BD8,
    Unknown_8375BE4,
    Unknown_8375BF0,
    Unknown_8375BFC,
    Unknown_8375C08,
    Unknown_8375C14,
    Unknown_8375C20,
    Unknown_8375C2C,
    Unknown_8375C38,
    Unknown_8375C44,
    Unknown_8375C50,
    Unknown_8375C5C,
    Unknown_8375C68,
    Unknown_8375C74,
    Unknown_8375C80,
    Unknown_8375C8C,
    Unknown_8375C98,
    Unknown_8375CA0,
    Unknown_8375CA8,
    Unknown_8375CB0,
    Unknown_8375CB8,
    Unknown_8375CC4,
    Unknown_8375CD0,
    Unknown_8375CDC,
    Unknown_8375CE8,
    Unknown_8375CF4,
    Unknown_8375D00,
    Unknown_8375D0C,
    Unknown_8375D18,
    Unknown_8375D24,
    Unknown_8375D30,
    Unknown_8375D3C,
    Unknown_8375D48,
    Unknown_8375D50,
    Unknown_8375D5C,
    Unknown_8375D64,
    Unknown_8375D6C,
    Unknown_8375D74,
    Unknown_8375D7C,
    Unknown_8375D84,
    Unknown_8375D8C,
    Unknown_8375D94,
    Unknown_8375D9C,
    Unknown_8375DA4,
    Unknown_8375DB0,
    Unknown_8375DC0,
    Unknown_8375DD0,
    Unknown_8375DD8,
    Unknown_8375DE0,
    Unknown_8375DE8,
    Unknown_8375DF0,
    Unknown_8375DFC,
    Unknown_8375E08,
    Unknown_8375E10,
    Unknown_8375E18,
    Unknown_8375E20,
    Unknown_8375E28,
    Unknown_8375E34,
    Unknown_8375E40,
    Unknown_8375E4C,
    Unknown_8375E58,
    Unknown_8375E64,
    Unknown_8375E70,
    Unknown_8375E7C,
    Unknown_8375EB8,
    Unknown_8375EC4,
    Unknown_8375ED0,
    Unknown_8375EDC,
    Unknown_8375EE8,
    Unknown_8375EF4,
    Unknown_8375F00,
    Unknown_8375F0C,
    Unknown_8375F18,
    Unknown_8375F24,
    Unknown_8375F30,
    Unknown_8375F3C,
    Unknown_8375F48,
    Unknown_8375F54,
    Unknown_8375F60,
    Unknown_8375F6C,
    Unknown_8375F78,
    Unknown_8375F84,
    Unknown_8375F90,
    Unknown_8375F9C,
    Unknown_8375FA8,
    Unknown_8375FB4,
    Unknown_8375FC0,
    Unknown_8375FCC,
    Unknown_8375FD8,
    Unknown_8375FE4,
    Unknown_8375FF0,
    Unknown_8375FFC
};


u8 (*const Unknown_83759A0[])(struct MapObject *, struct Sprite *) = {
    sub_8060CE0,
    sub_8063474
};

u8 (*const Unknown_83759A8[])(struct MapObject *, struct Sprite *) = {
    sub_8060CF0,
    sub_8063474
};

u8 (*const Unknown_83759B0[])(struct MapObject *, struct Sprite *) = {
    sub_8060D00,
    sub_8063474
};

u8 (*const Unknown_83759B8[])(struct MapObject *, struct Sprite *) = {
    sub_8060D10,
    sub_8063474
};

u8 (*const gUnknown_083759C0[])(u8) = {
    get_go_image_anim_num,
    get_go_fast_image_anim_num,
    get_go_fast_image_anim_num,
    get_go_faster_image_anim_num,
    sub_805FD78
};

u8 (*const Unknown_83759D4[])(struct MapObject *, struct Sprite *) = {
    sub_8060F3C,
    sub_8060F5C,
    sub_8063474
};

u8 (*const Unknown_83759E0[])(struct MapObject *, struct Sprite *) = {
    sub_8060F7C,
    sub_8060F9C,
    sub_8063474
};

u8 (*const Unknown_83759EC[])(struct MapObject *, struct Sprite *) = {
    sub_8060FBC,
    sub_8060FDC,
    sub_8063474
};

u8 (*const Unknown_83759F8[])(struct MapObject *, struct Sprite *) = {
    sub_8060FFC,
    sub_806101C,
    sub_8063474
};

u8 (*const Unknown_8375A04[])(struct MapObject *, struct Sprite *) = {
    sub_806103C,
    sub_806105C,
    sub_8063474
};

u8 (*const Unknown_8375A10[])(struct MapObject *, struct Sprite *) = {
    sub_806107C,
    sub_806109C,
    sub_8063474
};

u8 (*const Unknown_8375A1C[])(struct MapObject *, struct Sprite *) = {
    sub_80610BC,
    sub_80610DC,
    sub_8063474
};

u8 (*const Unknown_8375A28[])(struct MapObject *, struct Sprite *) = {
    sub_80610FC,
    sub_806111C,
    sub_8063474
};

const s16 gUnknown_08375A34[] = {0, 1, 1};
const s16 gUnknown_08375A3A[] = {0, 0, 1};

u8 (*const Unknown_8375A40[])(struct MapObject *, struct Sprite *) = {
    sub_80613A8,
    sub_80613D4,
    sub_8063474
};

u8 (*const Unknown_8375A4C[])(struct MapObject *, struct Sprite *) = {
    sub_8061400,
    sub_806142C,
    sub_8063474
};

u8 (*const Unknown_8375A58[])(struct MapObject *, struct Sprite *) = {
    sub_8061458,
    sub_8061484,
    sub_8063474
};

u8 (*const Unknown_8375A64[])(struct MapObject *, struct Sprite *) = {
    sub_80614B0,
    sub_80614DC,
    sub_8063474
};

u8 (*const Unknown_8375A70[])(struct MapObject *, struct Sprite *) = {
    sub_806152C,
    sub_8061510,
    sub_8063470
};

u8 (*const Unknown_8375A7C[])(struct MapObject *, struct Sprite *) = {
    sub_806154C,
    sub_8061510,
    sub_8063470
};

u8 (*const Unknown_8375A88[])(struct MapObject *, struct Sprite *) = {
    sub_806156C,
    sub_8061510,
    sub_8063470
};

u8 (*const Unknown_8375A94[])(struct MapObject *, struct Sprite *) = {
    sub_806158C,
    sub_8061510,
    sub_8063470
};

u8 (*const Unknown_8375AA0[])(struct MapObject *, struct Sprite *) = {
    sub_80615AC,
    sub_8061510,
    sub_8063470
};

u8 (*const Unknown_8375AAC[])(struct MapObject *, struct Sprite *) = {
    sub_80615CC,
    sub_80615EC,
    sub_8063474
};

u8 (*const Unknown_8375AB8[])(struct MapObject *, struct Sprite *) = {
    sub_806160C,
    sub_806162C,
    sub_8063474
};

u8 (*const Unknown_8375AC4[])(struct MapObject *, struct Sprite *) = {
    sub_806164C,
    sub_806166C,
    sub_8063474
};

u8 (*const Unknown_8375AD0[])(struct MapObject *, struct Sprite *) = {
    sub_806168C,
    sub_80616AC,
    sub_8063474
};

u8 (*const Unknown_8375ADC[])(struct MapObject *, struct Sprite *) = {
    sub_8061778,
    sub_806173C,
    sub_8063474
};

u8 (*const Unknown_8375AE8[])(struct MapObject *, struct Sprite *) = {
    sub_80617B0,
    sub_806173C,
    sub_8063474
};

u8 (*const Unknown_8375AF4[])(struct MapObject *, struct Sprite *) = {
    sub_80617E8,
    sub_806173C,
    sub_8063474
};

u8 (*const Unknown_8375B00[])(struct MapObject *, struct Sprite *) = {
    sub_8061820,
    sub_806173C,
    sub_8063474
};

u8 (*const Unknown_8375B0C[])(struct MapObject *, struct Sprite *) = {
    sub_8061858,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B18[])(struct MapObject *, struct Sprite *) = {
    sub_8061890,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B24[])(struct MapObject *, struct Sprite *) = {
    sub_80618C8,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B30[])(struct MapObject *, struct Sprite *) = {
    sub_8061900,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B3C[])(struct MapObject *, struct Sprite *) = {
    sub_8061938,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B48[])(struct MapObject *, struct Sprite *) = {
    sub_8061970,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B54[])(struct MapObject *, struct Sprite *) = {
    sub_80619A8,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B60[])(struct MapObject *, struct Sprite *) = {
    sub_80619E0,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B6C[])(struct MapObject *, struct Sprite *) = {
    sub_8061A18,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B78[])(struct MapObject *, struct Sprite *) = {
    sub_8061A50,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B84[])(struct MapObject *, struct Sprite *) = {
    sub_8061A88,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B90[])(struct MapObject *, struct Sprite *) = {
    sub_8061AC0,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375B9C[])(struct MapObject *, struct Sprite *) = {
    sub_8061AF8,
    sub_8061B18,
    sub_8063474
};

u8 (*const Unknown_8375BA8[])(struct MapObject *, struct Sprite *) = {
    sub_8061B38,
    sub_8061B58,
    sub_8063474
};

u8 (*const Unknown_8375BB4[])(struct MapObject *, struct Sprite *) = {
    sub_8061B78,
    sub_8061B98,
    sub_8063474
};

u8 (*const Unknown_8375BC0[])(struct MapObject *, struct Sprite *) = {
    sub_8061BB8,
    sub_8061BD8,
    sub_8063474
};

u8 (*const Unknown_8375BCC[])(struct MapObject *, struct Sprite *) = {
    sub_8061BF8,
    sub_8061C18,
    sub_8063474
};

u8 (*const Unknown_8375BD8[])(struct MapObject *, struct Sprite *) = {
    sub_8061C38,
    sub_8061C58,
    sub_8063474
};

u8 (*const Unknown_8375BE4[])(struct MapObject *, struct Sprite *) = {
    sub_8061C78,
    sub_8061C98,
    sub_8063474
};

u8 (*const Unknown_8375BF0[])(struct MapObject *, struct Sprite *) = {
    sub_8061CB8,
    sub_8061CD8,
    sub_8063474
};

u8 (*const Unknown_8375BFC[])(struct MapObject *, struct Sprite *) = {
    sub_8061CF8,
    sub_8061D18,
    sub_8063474
};

u8 (*const Unknown_8375C08[])(struct MapObject *, struct Sprite *) = {
    sub_8061D38,
    sub_8061D58,
    sub_8063474
};

u8 (*const Unknown_8375C14[])(struct MapObject *, struct Sprite *) = {
    sub_8061D78,
    sub_8061D98,
    sub_8063474
};

u8 (*const Unknown_8375C20[])(struct MapObject *, struct Sprite *) = {
    sub_8061DB8,
    sub_8061DD8,
    sub_8063474
};

u8 (*const Unknown_8375C2C[])(struct MapObject *, struct Sprite *) = {
    do_run_south_anim,
    sub_8061E18,
    sub_8063474
};

u8 (*const Unknown_8375C38[])(struct MapObject *, struct Sprite *) = {
    do_run_north_anim,
    sub_8061E58,
    sub_8063474
};

u8 (*const Unknown_8375C44[])(struct MapObject *, struct Sprite *) = {
    do_run_west_anim,
    sub_8061E98,
    sub_8063474
};

u8 (*const Unknown_8375C50[])(struct MapObject *, struct Sprite *) = {
    do_run_east_anim,
    sub_8061ED8,
    sub_8063474
};

u8 (*const Unknown_8375C5C[])(struct MapObject *, struct Sprite *) = {
    sub_8061F24,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375C68[])(struct MapObject *, struct Sprite *) = {
    sub_8061F90,
    sub_8061FB0,
    sub_8063474
};

u8 (*const Unknown_8375C74[])(struct MapObject *, struct Sprite *) = {
    sub_8061FD8,
    sub_8061FF8,
    sub_8063474
};

u8 (*const Unknown_8375C80[])(struct MapObject *, struct Sprite *) = {
    sub_8062020,
    sub_8062040,
    sub_8063474
};

u8 (*const Unknown_8375C8C[])(struct MapObject *, struct Sprite *) = {
    sub_8062068,
    sub_8062088,
    sub_8063474
};

u8 (*const Unknown_8375C98[])(struct MapObject *, struct Sprite *) = {
    sub_80620B0,
    sub_8063474
};

u8 (*const Unknown_8375CA0[])(struct MapObject *, struct Sprite *) = {
    sub_806210C,
    sub_8063474
};

u8 (*const Unknown_8375CA8[])(struct MapObject *, struct Sprite *) = {
    sub_8062170,
    sub_8063474
};

u8 (*const Unknown_8375CB0[])(struct MapObject *, struct Sprite *) = {
    sub_8062180,
    sub_8063474
};

u8 (*const Unknown_8375CB8[])(struct MapObject *, struct Sprite *) = {
    sub_8062190,
    sub_80621BC,
    sub_8063474
};

u8 (*const Unknown_8375CC4[])(struct MapObject *, struct Sprite *) = {
    sub_80621E8,
    sub_8062214,
    sub_8063474
};

u8 (*const Unknown_8375CD0[])(struct MapObject *, struct Sprite *) = {
    sub_8062240,
    sub_806226C,
    sub_8063474
};

u8 (*const Unknown_8375CDC[])(struct MapObject *, struct Sprite *) = {
    sub_8062298,
    sub_80622C4,
    sub_8063474
};

u8 (*const Unknown_8375CE8[])(struct MapObject *, struct Sprite *) = {
    sub_80622F0,
    sub_806231C,
    sub_8063474
};

u8 (*const Unknown_8375CF4[])(struct MapObject *, struct Sprite *) = {
    sub_8062348,
    sub_8062374,
    sub_8063474
};

u8 (*const Unknown_8375D00[])(struct MapObject *, struct Sprite *) = {
    sub_80623A0,
    sub_80623CC,
    sub_8063474
};

u8 (*const Unknown_8375D0C[])(struct MapObject *, struct Sprite *) = {
    sub_80623F8,
    sub_8062424,
    sub_8063474
};

u8 (*const Unknown_8375D18[])(struct MapObject *, struct Sprite *) = {
    sub_8062450,
    sub_806247C,
    sub_8063474
};

u8 (*const Unknown_8375D24[])(struct MapObject *, struct Sprite *) = {
    sub_80624A8,
    sub_80624D4,
    sub_8063474
};

u8 (*const Unknown_8375D30[])(struct MapObject *, struct Sprite *) = {
    sub_8062500,
    sub_806252C,
    sub_8063474
};

u8 (*const Unknown_8375D3C[])(struct MapObject *, struct Sprite *) = {
    sub_8062558,
    sub_8062584,
    sub_8063474
};

u8 (*const Unknown_8375D48[])(struct MapObject *, struct Sprite *) = {
    sub_80625B0,
    sub_8063474
};

u8 (*const Unknown_8375D50[])(struct MapObject *, struct Sprite *) = {
    sub_80625C8,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375D5C[])(struct MapObject *, struct Sprite *) = {
    sub_80625D8,
    sub_8063470
};

u8 (*const Unknown_8375D64[])(struct MapObject *, struct Sprite *) = {
    sub_80625E8,
    sub_8063470
};

u8 (*const Unknown_8375D6C[])(struct MapObject *, struct Sprite *) = {
    sub_80625F8,
    sub_8063470
};

u8 (*const Unknown_8375D74[])(struct MapObject *, struct Sprite *) = {
    sub_8062608,
    sub_8063470
};

u8 (*const Unknown_8375D7C[])(struct MapObject *, struct Sprite *) = {
    sub_8062634,
    sub_8063470
};

u8 (*const Unknown_8375D84[])(struct MapObject *, struct Sprite *) = {
    sub_8062644,
    sub_8063470
};

u8 (*const Unknown_8375D8C[])(struct MapObject *, struct Sprite *) = {
    do_exclamation_mark_bubble_1,
    sub_8063470
};

u8 (*const Unknown_8375D94[])(struct MapObject *, struct Sprite *) = {
    do_exclamation_mark_bubble_2,
    sub_8063470
};

u8 (*const Unknown_8375D9C[])(struct MapObject *, struct Sprite *) = {
    do_heart_bubble,
    sub_8063470
};

u8 (*const Unknown_8375DA4[])(struct MapObject *, struct Sprite *) = {
    sub_80626C0,
    sub_8062704,
    sub_8063470
};

u8 (*const Unknown_8375DB0[])(struct MapObject *, struct Sprite *) = {
    sub_8062724,
    sub_8062740,
    sub_8062764,
    sub_8063470
};

u8 (*const Unknown_8375DC0[])(struct MapObject *, struct Sprite *) = {
    sub_80627A0,
    sub_80627BC,
    sub_80627E0,
    sub_8063470
};

u8 (*const Unknown_8375DD0[])(struct MapObject *, struct Sprite *) = {
    sub_806281C,
    sub_8063470
};

u8 (*const Unknown_8375DD8[])(struct MapObject *, struct Sprite *) = {
    sub_806282C,
    sub_8063470
};

u8 (*const Unknown_8375DE0[])(struct MapObject *, struct Sprite *) = {
    sub_806283C,
    sub_8063470
};

u8 (*const Unknown_8375DE8[])(struct MapObject *, struct Sprite *) = {
    sub_806286C,
    sub_8063470
};

u8 (*const Unknown_8375DF0[])(struct MapObject *, struct Sprite *) = {
    sub_806289C,
    sub_80628D0,
    sub_8063474
};

u8 (*const Unknown_8375DFC[])(struct MapObject *, struct Sprite *) = {
    sub_80628FC,
    sub_8062930,
    sub_8063474
};

u8 (*const Unknown_8375E08[])(struct MapObject *, struct Sprite *) = {
    sub_806299C,
    sub_8063474
};

u8 (*const Unknown_8375E10[])(struct MapObject *, struct Sprite *) = {
    sub_80629AC,
    sub_8063474
};

u8 (*const Unknown_8375E18[])(struct MapObject *, struct Sprite *) = {
    sub_80629BC,
    sub_8063474
};

u8 (*const Unknown_8375E20[])(struct MapObject *, struct Sprite *) = {
    sub_80629CC,
    sub_8063474
};

u8 (*const Unknown_8375E28[])(struct MapObject *, struct Sprite *) = {
    sub_80629DC,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375E34[])(struct MapObject *, struct Sprite *) = {
    sub_8062A00,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375E40[])(struct MapObject *, struct Sprite *) = {
    sub_8062A24,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375E4C[])(struct MapObject *, struct Sprite *) = {
    sub_8062A48,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375E58[])(struct MapObject *, struct Sprite *) = {
    sub_8062A6C,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375E64[])(struct MapObject *, struct Sprite *) = {
    sub_8062A90,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375E70[])(struct MapObject *, struct Sprite *) = {
    sub_8062AB4,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375E7C[])(struct MapObject *, struct Sprite *) = {
    sub_8062AD8,
    sub_8061F3C,
    sub_8063474,
    sub_8062AFC,
    sub_8061F3C,
    sub_8063474,
    sub_8062B20,
    sub_8061F3C,
    sub_8063474,
    sub_8062B44,
    sub_8061F3C,
    sub_8063474,
    sub_8062B68,
    sub_8061F3C,
    sub_8063474
};

u8 (*const Unknown_8375EB8[])(struct MapObject *, struct Sprite *) = {
    sub_8062BD0,
    sub_8062BFC,
    sub_8063474
};

u8 (*const Unknown_8375EC4[])(struct MapObject *, struct Sprite *) = {
    sub_8062C28,
    sub_8062C54,
    sub_8063474
};

u8 (*const Unknown_8375ED0[])(struct MapObject *, struct Sprite *) = {
    sub_8062C80,
    sub_8062CAC,
    sub_8063474
};

u8 (*const Unknown_8375EDC[])(struct MapObject *, struct Sprite *) = {
    sub_8062CD8,
    sub_8062D04,
    sub_8063474
};

u8 (*const Unknown_8375EE8[])(struct MapObject *, struct Sprite *) = {
    sub_8062D30,
    sub_8062D5C,
    sub_8063474
};

u8 (*const Unknown_8375EF4[])(struct MapObject *, struct Sprite *) = {
    sub_8062D88,
    sub_8062DB4,
    sub_8063474
};

u8 (*const Unknown_8375F00[])(struct MapObject *, struct Sprite *) = {
    sub_8062DE0,
    sub_8062E0C,
    sub_8063474
};

u8 (*const Unknown_8375F0C[])(struct MapObject *, struct Sprite *) = {
    sub_8062E38,
    sub_8062E64,
    sub_8063474
};

u8 (*const Unknown_8375F18[])(struct MapObject *, struct Sprite *) = {
    sub_8062E90,
    sub_8062EBC,
    sub_8063474
};

u8 (*const Unknown_8375F24[])(struct MapObject *, struct Sprite *) = {
    sub_8062EE8,
    sub_8062F14,
    sub_8063474
};

u8 (*const Unknown_8375F30[])(struct MapObject *, struct Sprite *) = {
    sub_8062F40,
    sub_8062F6C,
    sub_8063474
};

u8 (*const Unknown_8375F3C[])(struct MapObject *, struct Sprite *) = {
    sub_8062F98,
    sub_8062FC4,
    sub_8063474
};

u8 (*const Unknown_8375F48[])(struct MapObject *, struct Sprite *) = {
    sub_8062FF0,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375F54[])(struct MapObject *, struct Sprite *) = {
    sub_8063028,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375F60[])(struct MapObject *, struct Sprite *) = {
    sub_8063060,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375F6C[])(struct MapObject *, struct Sprite *) = {
    sub_8063098,
    sub_8061714,
    sub_8063474
};

u8 (*const Unknown_8375F78[])(struct MapObject *, struct Sprite *) = {
    sub_8063108,
    sub_8063128,
    sub_8063474
};

u8 (*const Unknown_8375F84[])(struct MapObject *, struct Sprite *) = {
    sub_8063148,
    sub_8063168,
    sub_8063474
};

u8 (*const Unknown_8375F90[])(struct MapObject *, struct Sprite *) = {
    sub_8063188,
    sub_80631A8,
    sub_8063474
};

u8 (*const Unknown_8375F9C[])(struct MapObject *, struct Sprite *) = {
    sub_80631C8,
    sub_80631E8,
    sub_8063474
};

u8 (*const Unknown_8375FA8[])(struct MapObject *, struct Sprite *) = {
    sub_8063238,
    sub_8063258,
    sub_8063474
};

u8 (*const Unknown_8375FB4[])(struct MapObject *, struct Sprite *) = {
    sub_8063278,
    sub_8063298,
    sub_8063474
};

u8 (*const Unknown_8375FC0[])(struct MapObject *, struct Sprite *) = {
    sub_80632B8,
    sub_80632D8,
    sub_8063474
};

u8 (*const Unknown_8375FCC[])(struct MapObject *, struct Sprite *) = {
    sub_80632F8,
    sub_8063318,
    sub_8063474
};

u8 (*const Unknown_8375FD8[])(struct MapObject *, struct Sprite *) = {
    sub_8063370,
    sub_8063390,
    sub_8063474
};

u8 (*const Unknown_8375FE4[])(struct MapObject *, struct Sprite *) = {
    sub_80633B0,
    sub_80633D0,
    sub_8063474
};

u8 (*const Unknown_8375FF0[])(struct MapObject *, struct Sprite *) = {
    sub_80633F0,
    sub_8063410,
    sub_8063474
};

u8 (*const Unknown_8375FFC[])(struct MapObject *, struct Sprite *) = {
    sub_8063430,
    sub_8063450,
    sub_8063474
};

#endif //POKERUBY_ANIM_FUNC_PTRS_H
